package com.cf.spring.SpringDemo4_B2;

public class Address {
	int pin;
	String streetName;
	public Address() {
		System.out.println("addr obj craeted");
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	@Override
	public String toString() {
		return "Address [pin=" + pin + ", streetName=" + streetName + "]";
	}
	
}
