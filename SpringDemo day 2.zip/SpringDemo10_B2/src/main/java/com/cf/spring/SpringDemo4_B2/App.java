package com.cf.spring.SpringDemo4_B2;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {

    	//implement aggregation relationship
    	// remove the address prop from the emp bean tag
//    	ApplicationContext actx=new FileSystemXmlApplicationContext("spring-mybean.xml");
//    	Emp e=(Emp)actx.getBean("emp");
//    	System.out.println(e);
//    	System.out.println(e.getAddr());
//    	System.out.println(e.getAddr().pin);

    	//implement composition relationship
    	//i should not the 3rd prop whgich address from emp bean tag
    	ApplicationContext actx=new FileSystemXmlApplicationContext("spring-mybean.xml");
    	Emp e=(Emp)actx.getBean("emp");
    	System.out.println(e);
    	System.out.println(e.getAddr());
    //	System.out.println(e.getAddr().pin);

    }
}
