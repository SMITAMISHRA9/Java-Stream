package com.cf.spring.SpringDemo4_B2;

import org.springframework.beans.factory.annotation.Required;

public class Emp {	
	
	private int empId;
	private String empName;

	private Address addr;
	
		public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddr() {
		return addr;
	}
	@Required
	public void setAddr(Address addr) {
		this.addr = addr;
	}

		Emp(){
			System.out.println("emp obj created");
		}

		@Override
		public String toString() {
			return "Emp [empId=" + empId + ", empName=" + empName + ", addr=" + addr + "]";
		}
		
	
}
