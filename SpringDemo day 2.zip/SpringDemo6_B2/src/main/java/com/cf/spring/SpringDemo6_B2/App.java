package com.cf.spring.SpringDemo6_B2;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class App 
{
    public static void main( String[] args )
    {
    ApplicationContext actx=new FileSystemXmlApplicationContext("spring-mybean.xml");
   Emp e= actx.getBean("emp",Emp.class);	
   System.out.println(e);
   System.out.println(e.hashCode());
   Emp e1= actx.getBean("emp",Emp.class);	
   System.out.println(e1);
   System.out.println(e1.hashCode());
    }
}
