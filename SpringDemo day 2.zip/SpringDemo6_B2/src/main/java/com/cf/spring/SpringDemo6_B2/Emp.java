package com.cf.spring.SpringDemo6_B2;

public class Emp {	
		Emp(){
			System.out.println("emp obj created");
		}
}
