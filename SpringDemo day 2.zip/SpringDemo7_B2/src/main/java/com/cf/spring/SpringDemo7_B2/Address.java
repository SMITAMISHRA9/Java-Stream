package com.cf.spring.SpringDemo7_B2;

public class Address {
public Address() {
	System.out.println("addr created");
}
}
