package com.cf.spring.SpringDemo7_B2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	//ApplicationContext ctx=new AnnotationConfigApplicationContext(AppConfig.class);
    	//ctx.register()
    	//ctx.refresh();
    	AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
    	ctx.register(AppConfig.class);//dynamic config loading
    	ctx.refresh();
    	Emp e=ctx.getBean("createEmp",Emp.class);
    	System.out.println(e);
    	System.out.println(e.getAddr());
    }
}
