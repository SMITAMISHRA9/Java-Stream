package com.cf.spring.SpringDemo7_B2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {
	
	@Bean
	Emp createEmp(){
		//return new Emp(createAddr());
		Emp e=new Emp();
		e.setAddr(createAddr());
		return e;
	}
	@Bean
	Address createAddr(){
		return new Address();
	}
	
}
