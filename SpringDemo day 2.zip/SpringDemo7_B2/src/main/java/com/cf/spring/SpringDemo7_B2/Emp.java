package com.cf.spring.SpringDemo7_B2;

public class Emp {	
	
	private int empId;
	private String empName;
	private Address addr;
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
		public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

		Emp(){
			System.out.println("employee obj created");
		}
		Emp(Address adrr){
			this.addr=adrr;
		}
		@Override
		public String toString() {
			return "Emp [empId=" + empId + ", empName=" + empName +"]";
		}
		
	
}
