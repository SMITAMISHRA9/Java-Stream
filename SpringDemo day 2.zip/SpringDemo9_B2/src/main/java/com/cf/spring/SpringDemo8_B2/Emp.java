package com.cf.spring.SpringDemo8_B2;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

//@Component //@service//@Repository//@Controller
//in pool , it takes the name of the class as key/ name but first cchar is in lower case
//emp
@ComponentScan(basePackages = "com.cf.*")
@Component("employee")
public class Emp {	
	
	private int empId;
	private String empName;
	
	
		public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}


		Emp(){
			System.out.println("emp obj created");
		}

		@Override
		public String toString() {
			return "Emp [empId=" + empId + ", empName=" + empName +  "]";
		}
		
	
}
